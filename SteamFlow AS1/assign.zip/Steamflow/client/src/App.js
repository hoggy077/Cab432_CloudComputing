import React from 'react';
import { Route, Routes } from 'react-router-dom';

import './App.css';
import Home from './Pages/Home/Home';
import AppIDPage from './Pages/AppIDPage/AppIDPage';
import List from './Pages/List/List';

class App extends React.Component {
    render() {
        return (
            <Routes>
                <Route path="/" element={<Home />}></Route>
                <Route path="/list/:sid" element={<List />}></Route>
                <Route path="/:appid" element={<AppIDPage />}></Route>
            </Routes>
        );
    }
}


//Context:
//useNavigation is only available in function components
//So, this is a functional component that wraps a class component allowing the parse of the nav hook
export default App;
