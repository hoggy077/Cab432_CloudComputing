import React from "react";

import './Featured.css';


class Featured extends React.Component {
    render() {
        return (
            <div id="appItem">
                <a href={`/${this.props.cont.aid}`}>
                    <div id="appImg">
                        <img alt="" src={this.props.cont.img} />
                    </div>
                    <div id="Name">
                        <p>{this.props.cont.name}</p>
                    </div>
                </a>
            </div>
        );
    }
}

export default Featured;