import React from 'react';

import css from "./List.css";
import Featured from "./Components/Featured";

import Searchbar from "../../Components/Searchbar/Searchbar";
import BackBtn from '../../Components/Back/BackBtn';
import { useParams } from 'react-router-dom'

class ListBase extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            ID: props.sid,
            isValid: false,
            userAccessible:
            {
                state: true,
                msg: ""
            },
            target:null,
            evaluated: {
                featured: {
                    state: false,
                    path: (e)=>"/api/v1/featured"
                },
                decimal: {
                    state: false,
                    path: (e) => `/api/v1/wishlist/${e}`
                }
            },
            apps: []
        };
    }


    async componentDidMount() {
        //ID can be any value, which might be a problem.
        //Accepted values are
        //1. featured
        //2. Decimal format of steam id

        //#region Evaluate param
        var tmpstate = this.state;
        tmpstate.evaluated.featured.state = this.state.ID == "featured";
        tmpstate.evaluated.decimal.state = !isNaN(this.state.ID);

        if (!tmpstate.evaluated.featured.state && !tmpstate.evaluated.decimal.state)
            return;
        else {

            if (tmpstate.evaluated.featured.state)
                tmpstate.target = tmpstate.evaluated.featured.path
            else
                tmpstate.target = tmpstate.evaluated.decimal.path

            tmpstate.isValid = true;
            this.setState(tmpstate);
        }
        //#endregion


        var result = await fetch(this.state.target(this.state.ID));
        console.log(result);
        if (result.status != 200) {
            //general error IDK
            tmpstate.userAccessible = {
                state: false,
                msg: "An unkown error came up with this account."
            }
            this.setState(tmpstate);
        }

        if (result.status == 500) {
            //this one is specific
            tmpstate.userAccessible = {
                state: false,
                msg: "That user is inaccessible. Please check your account & game details are public."
            }
            this.setState(tmpstate);
        }

        //put this here as extra precaution
        if (!this.state.userAccessible.state)
            return;

        result = await result.json();
        if (this.state.evaluated.decimal.state)
            result = this.parse2Array(result);
        else
            result = this.mergeFeatures(result);

        var commonData = this.parse2common(result, this.state.evaluated.featured.state);
        tmpstate = this.state;
        tmpstate.apps = commonData;
        this.setState(tmpstate);
    }

    parse2Array(objMap) {
        return Object.entries(objMap).map((ent) => {
            var v = ent[1];
            v.id = ent[0]
            return v;
        })
    }

    parse2common(gamArr, isFeatured) {
        return gamArr.map((item) => {
            if (isFeatured)
                return {
                    aid: item.id,
                    name: item.name,
                    img: item.header_image,
                    patforms: {
                        win: item.windows_available,
                        mac: item.mac_available,
                        linux: item.linux_available
                    }
                }
            else
                return {
                    aid: parseInt(item.id),
                    name: item.name,
                    img: item.capsule,
                    patforms: {
                        win: "win" in item,
                        mac: "mac" in item,
                        linux: "linux" in item
                    }
                }
        });
    }

    mergeFeatures(basejson) {
        var tagged = [];
        var win = basejson.featured_win.filter((item) => {
            var r = !tagged.includes(item.id)
            if (r)
                tagged.push(item.id);
            return r;
        });

        var mac = basejson.featured_mac.filter((item) => {
            var r = !tagged.includes(item.id)
            if (r)
                tagged.push(item.id);
            return r;
        });

        var lin = basejson.featured_linux.filter((item) => {
            var r = !tagged.includes(item.id)
            if (r)
                tagged.push(item.id);
            return r;
        });
        return win.concat(mac, lin);
    }

    render() {
        return (
            <div className="App">
                <BackBtn />
                {this.state.isValid && this.state.userAccessible.state ?
                    (
                        <div id="listGrid">
                            <div id="sbarWrap" className="flexCenter">
                                <Searchbar options={[
                                    { Name: "Wishlist", placeholder: "Steam64 ID", path: (sid) => `/list/${sid}` }
                                ]} />
                            </div>
                            <div id="appList">
                                {
                                    this.state.apps.map((item, index) => {
                                        return <Featured cont={item} key={index} />
                                    })
                                }
                            </div>
                        </div>
                    ):
                    (
                        <div id="error" style={{ height: '100vh' }}>
                            <h1>An Error has occured.</h1>
                            <h2>
                                {this.state.isValid && !this.state.userAccessible.state ? this.state.userAccessible.msg : `Please provide either "featured" or a 64bit steamID` }
                            </h2>
                        </div>
                    )
                }
            </div>
        );
    }
}

export default function List(props) {
    let { sid } = useParams();
    return (<ListBase sid={sid} />);
};
