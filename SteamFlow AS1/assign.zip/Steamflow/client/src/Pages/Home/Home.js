import React from 'react';

import ViewCount from "./Components/ViewCount/ViewCount";
import Searchbar from "../../Components/Searchbar/Searchbar";


class Home extends React.Component {
    state = {
        views: { count: null, failed: false }
    }

    componentDidMount() {
        //Update view count and parse it on to the view count
        fetch('/api/v1/views?update=true').then(async (res) => {
            if (res.status !== 200)
                throw new Error();
            var text = await res.text().then();
            this.setState({ views: { count: text, failed: false } });
        }).catch(() => {
            this.setState({ views: { count: null, failed: true } })
        });
    }

    render() {
        return (
            <div className="App flexCenter">
                <Searchbar options={[
                    { Name: "AppID", placeholder: "App ID", path: (appid) => `/${appid}` },
                    { Name: "Wishlist", placeholder: "Steam64 ID", path: (sid) => `/list/${sid}` },
                    { Name: "Featured", placeholder: "Press enter to continue...", path: (plc) => `/list/featured` }
                ]} />
                <ViewCount views={this.state.views} />
            </div>
        );
    }
}

export default Home;
