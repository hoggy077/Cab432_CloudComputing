import React from "react";

import logo from "../Resources/visibility_white_24dp.svg"
import './ViewCount.css'


//{value: N} where N is the count
class ViewCount extends React.Component {
    componentDidMount() {
        
    }


    //container
        //Icon
        //Text

    render() {
        return (
            <div id="fixedViewCont">
                {!this.props.views.failed ? (
                    <div id="ViewCont">
                        < img src={logo} alt="View count" style={{ margin: "10px" }} />
                        <span>Views: {this.props.views.count}</span>
                    </div>)
                    :
                    (<div>
                        View count couldn't be acquired.
                    </div>)
                }
            </div>
            
        );
    }
}

export default ViewCount;