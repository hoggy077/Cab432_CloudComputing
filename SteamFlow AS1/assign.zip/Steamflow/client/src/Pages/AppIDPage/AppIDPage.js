import React from 'react';
import { useParams } from 'react-router-dom'

//import './AppIDPage.css';
import BackBtn from '../../Components/Back/BackBtn'
import DynamicIsland from './Component/DynamicIsland/DynamicIsland'
import YoutubeItem from './Component/Youtube/YoutubeItem'
import './AppIDPage.css'

class AppPage extends React.Component {
    constructor(params) {
        super(params);
        this.state = {
            appID: params.appid,
            gameInfo: {
                Name: null,
                bannerURL: null,
                Description: null,
                Website: null,
                platforms: {},
                totalreviews: null,
                isPaid: false
            },
            youtubeInfo: [],
            youtubeAvail: false,
            gameAvail: false,
            hadError: false,
            ErrorDisplayMsg: ""
        };
    }

    async componentDidMount() {
        var tmpState = this.state;
        var result = await fetch(`/api/v1/games/${this.state.appID}`);
        if (result.status == 200) {
            var json = await result.json();
            console.log(json)
            tmpState.gameInfo = {
                Name: json.name,
                bannerURL: json.background,
                Description: json.about_the_game,
                Website: json.website,
                Devs: json.developers,
                platforms: json.platforms,
                totalreviews: "recommendations" in json ? json.recommendations.total : null,
                isPaid: !json.is_free
            };
            tmpState.gameAvail = true;

            if ("status" in json.Youtube) {
                tmpState.youtubeAvail = false;
                tmpState.youtubeInfo = json.Youtube.data.error;
                this.setState(tmpState);
                return;
            }

            tmpState.youtubeInfo = json.Youtube.items;
            tmpState.youtubeAvail = true;
            tmpState.hadError = false;

            this.setState(tmpState);
            return;
        }


        //this in the case of join means Steam has returned an error, as Youtubes entry will be its error for diplaying front end
        //the error can be:
        //a. 404: appID is valid but the app itself wasn't available
        //b. 400: appID isn't valid or wasn't included
        //c. 500: the server has hit an error I couldn't reach in testing and crashed

        if (result.status != 200) {
            //an error I haven't expected
            tmpState.ErrorDisplayMsg = "We're not sure what went wrong there! Sorry about that.";
            tmpState.hadError = true;
        }

        if (result.status == 400) {
            tmpState.ErrorDisplayMsg = "Looks like Steam doesn't like that App.";
            tmpState.hadError = true;
        }

        if (result.status == 404) {
            tmpState.ErrorDisplayMsg = "We sadly couldn't get the details of this game.";
            tmpState.hadError = true;
        }

        if (result.status == 500) {
            tmpState.ErrorDisplayMsg = "There has been an error on our end! Sorry about that.";
            tmpState.hadError = true;
        }

        this.setState(tmpState);
    }

    render() {
        return (
            <div className="App" >
                <div className={`${this.state.hadError ? "flexCenter" : ""}`} style={{ height: this.state.hadError ? "100vh" : "" }}>
                    <BackBtn />
                    {this.state.hadError ?
                        (
                            <div id="error">
                                <h1>An Error has occured!</h1>
                                <h2>{this.state.ErrorDisplayMsg}</h2>
                            </div>
                        ):
                        (
                            //Grid
                            <div id="AppGrid">
                                <div className="headerimg" style={{ backgroundImage: `url(${this.state.gameInfo.bannerURL})` }} alt="" />
                                <div id="col2">
                                    {/*Middle - Game details + platforms + reviews*/}
                                    <h1>{this.state.gameInfo.Name}</h1>
                                    <DynamicIsland details={this.state.gameInfo} />
                                    <p dangerouslySetInnerHTML={{ __html: this.state.gameInfo.Description }}></p>
                                    
                                </div>
                                <div id="col3">
                                    {/*Right - Youtube stuff*/}
                                    {this.state.youtubeAvail ? (

                                        this.state.youtubeInfo.map((item, index) => {
                                            var vidInf = {
                                                id: item.id.videoId,
                                                snippet: item.snippet
                                            };
                                            return <YoutubeItem key={index} vidInf={vidInf} />
                                        })
                                    ) :
                                        (<h3>{this.state.youtubeInfo}</h3>)
                                    }
                                </div>
                            </div>
                        )
                    }
                </div>
            </div>
        );
    }
}



export default function AppIDPage(params) {
    let { appid } = useParams();
    return (<AppPage appid={appid} />)
};
