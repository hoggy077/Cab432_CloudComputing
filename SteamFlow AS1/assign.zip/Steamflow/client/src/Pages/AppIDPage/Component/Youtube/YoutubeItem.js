import React from "react";

import './YoutubeItem.css'

class YoutubeItem extends React.Component {
    render() {
        return (
            <a aria-label="video name" href={`https://www.youtube.com/watch?v=${this.props.vidInf.id}`} target="_blank" rel="noreferrer" id="ytLink">
                <div className="ytcontent">
                    {/*thumbnail*/}
                    <div className="imgcrop">
                        <img alt="" src={this.props.vidInf.snippet.thumbnails.high.url} />
                    </div>
                    <div id="titleBar">
                        {/*Video Name*/}
                        <p>{this.props.vidInf.snippet.title}</p>
                    </div>
                </div>
            </a>
        );
    }
}

export default YoutubeItem;