import React from 'react';

import './DynamicIsland.css'
import Windows_Ico from '../Resources/Windows_white.svg'
import Linux_Ico from '../Resources/Linux_white.svg'
import Mac_Ico from '../Resources/Mac_white.svg'
import Review_Ico from '../Resources/rate_review_white_24dp.svg'
import Paid_Ico from '../Resources/paid_white_24dp.svg'

class DynamicIsland extends React.Component {

    NumInfo(num) {
        var Units = ["", "K", "M", "B", "T", "Q"]
        if (num < 0)
            num = num * -1;
        if (num == 0)
            return "0";
        var off = Math.floor(Math.log10(num) + 1) % 3;
        var result = {
            ind: Math.floor(Math.log10(num) / 3),
            offset: off == 0 ? 3 : off,
            str: num.toString()
        }
        return `${result.str.slice(0, result.offset)}${result.str.length > 3 ? "." : ""}${result.str.slice(result.offset, result.offset + 2)}${Units[result.ind]}`
    }

    render() {
        return (
            <div id="dynamicIsland" >
                {this.props.details.platforms.windows && (<img src={Windows_Ico} alt="Windows" height='24px'/>)}
                {this.props.details.platforms.mac && (<img src={Mac_Ico} alt="Mac OS" height='24px' />)}
                {this.props.details.platforms.linux && (<img src={Linux_Ico} alt="Linux" height='24px' />)}
                {this.props.details.isPaid && (<img src={Paid_Ico} alt="Paid" height='24px' />)}
                {this.props.details.totalreviews != null ? 
                    (
                        <div>
                            <img src={Review_Ico} alt={`Total Reviews: ${this.props.details.totalreviews}`} />
                            <label>{`Total Reviews: ${this.NumInfo(this.props.details.totalreviews)}`}</label>
                        </div>
                    ):
                    (
                        <div id="none" />
                    )

                }
                
                
            </div>
        );
    }
}

export default DynamicIsland