import { useNavigate } from 'react-router-dom'

import './BackBtn.css'
import leftarrow from './Resources/arrow_left_white_24dp.svg'

//functional component
export default function BackBtn() {
    const nav = useNavigate();
    return (
        <div id="Backbtn" onClick={() => nav(-1)}>
            <img alt="" src={leftarrow} />
        </div>
    );
};