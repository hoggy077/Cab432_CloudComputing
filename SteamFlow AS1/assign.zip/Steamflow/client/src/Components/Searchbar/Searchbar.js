import React from "react";

import './Searchbar.css'
import SearchbarEntry from './SearchbarEntry';


class Searchbar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            children: props.options,
            selected: 0,
            visible: false
        };
        this.inputDom = null;
        this.finalPath = "";
    }

    componentDidMount() {
        this.inputDom.addEventListener("keypress", this.InputHandled);
    }

    EntryUpdated = (evnt, index) => {
        var clone = this.state;

        if (this.state.selected == index && !this.state.visible) {
            //we clicked an option, but the others aren't visible
            clone.visible = true;
            this.setState(clone);
            return;
        }

        if (this.state.selected != index && this.state.visible) {
            clone.visible = false;
            clone.selected = index;
            this.setState(clone);
            return;
        }

        if (this.state.visible) {
            clone.visible = false;
            this.setState(clone);
        }
    }

    InputHandled = (evnt) => {
        if (evnt.key !== "Enter")
            return;

        if (this.inputDom.value == "")
            return;

        //we made it here, there is a value and Enter is hit.
        window.location.assign(this.state.children[this.state.selected].path(this.inputDom.value));
    }

    render() {
        return (
            <div id="searchBase">
                <div id="searchOP" style={{ overflow: this.state.visible ? "visible" : "hidden" }}>
                    <div style={{ top: `-${this.state.selected * 100}%` }}>
                        {
                            this.state.children.map((entry, index) => <SearchbarEntry value={entry.Name} key={index} index={index} onClick={this.EntryUpdated} />)
                        }
                    </div>
                </div>
                <input type="text" placeholder={this.state.children[this.state.selected].placeholder} ref={elem => this.inputDom = elem}></input>
            </div>
        );
    }
}

export default Searchbar;