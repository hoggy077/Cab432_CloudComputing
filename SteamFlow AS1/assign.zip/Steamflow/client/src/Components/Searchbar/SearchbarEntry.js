import React from "react";

import './SearchbarEntry.css';


class SearchbarEntry extends React.Component {
    state = {}
    constructor(props) {
        super(props);
        this.state = {
            Text: props.value,
            index: props.index
        }
    }


    render() {
        return (
            <div className="EntryItem" onClick={evnt => this.props.onClick(evnt, this.state.index)}>
                {this.state.Text}
            </div>
        );
    }
}

export default SearchbarEntry;