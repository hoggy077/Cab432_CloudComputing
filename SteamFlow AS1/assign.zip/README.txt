The docker-compose is for the purprose of caching.
I highly recommend using it for the performance benefit and the reduced strain
on both steam and Youtube.

If using the docker-compose, make sure to include the AWS credentials as enviromental variables.