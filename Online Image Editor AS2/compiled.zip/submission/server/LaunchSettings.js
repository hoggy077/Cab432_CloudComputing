require("dotenv").config();

module.exports = {
    exposedPort: process.env.exposedPort || 8080,
    DevKey: process.env.DevKey || undefined,
    buildPath: process.env.buildPath || "../../as2_client/build",
    redisSettings: process.env.redisSettings || {},
    S3Settings: process.env.S3Settings || {},
    cacheless: process.env.cacheless || false
}